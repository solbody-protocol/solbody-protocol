module HumanApi
  VERSION = "0.1.6"
end
